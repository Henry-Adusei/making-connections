var removal = document.querySelector(".card-list-item")

function remove_def() {
    removal.remove()
}

var removal1 = document.querySelector(".card-list-item1")

function remove_def1() {
    removal1.remove()
}

var nameChange = document.querySelector("#name1")

function change_name() {
    nameChange.innerText = "Henry Adusei";
}

// find a way to decrease the connection number when the x button is clicked and a way to increase the number when the mark button is clicked
